<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Guía del Turista</title>
	<link rel="stylesheet" href="Plugins/themes/fumysam.min.css" />
	<link rel="stylesheet" href="Plugins/themes/jquery.mobile.icons.min.css" />
	<link rel="stylesheet" href="https://code.jquery.com/mobile/1.4.5/jquery.mobile.structure-1.4.5.min.css" />
	<script src="https://code.jquery.com/jquery-1.11.1.min.js"></script>
	<script src="https://code.jquery.com/mobile/1.4.5/jquery.mobile-1.4.5.min.js"></script>
	<!-- Start WOWSlider.com HEAD section -->
	<link rel="stylesheet" type="text/css" href="Plugins/engine1/style.css" />
	<link rel="stylesheet" type="text/css" href="Plugins/icofont/css/icofont.css"/>
	<!-- End WOWSlider.com HEAD section -->
    
	<style>
		#pagina-mapa { width: 100%; height: 70%; padding: 0; }
		#map { width: 98%; height: 95%; }
		.titulo-local {
			color: #3eb249;
			background-color: transparent;
			border-bottom: 1px solid #ddd;
			font-size: 1.6em;
			padding-bottom: .2em;
			margin: 0 0 .7375em;
		}
		.w3_facebook_btn {
			border: 1px solid rgba(0, 0, 0, 0.1) !important;
			display: inline-block !important;
			position: relative !important;
			font-family: Arial,sans-serif !important;
			letter-spacing: .4px !important;
			cursor: pointer !important;
			font-weight: 400 !important;
			text-transform: none !important;
			color: #fff !important;
			border-radius: 2px !important;
			background-color: #4B4F9A !important;
			background-repeat: no-repeat !important;
			line-height: 1.2 !important;
			text-decoration: none !important;
			text-align: left !important;
			text-shadow: none !important;
		}
		.w3_face_messenger_btn {
			border: 1px solid rgba(0, 0, 0, 0.1) !important;
			display: inline-block !important;
			position: relative !important;
			font-family: Arial,sans-serif !important;
			letter-spacing: .4px !important;
			cursor: pointer !important;
			font-weight: 400 !important;
			text-transform: none !important;
			color: #fff !important;
			border-radius: 2px !important;
			background-color: #0084FF !important;
			background-repeat: no-repeat !important;
			line-height: 1.2 !important;
			text-decoration: none !important;
			text-align: left !important;
			text-shadow: none !important;
		}
		 .w3_whatsapp_btn {
			border: 1px solid rgba(0, 0, 0, 0.1) !important;
			display: inline-block !important;
			position: relative !important;
			font-family: Arial,sans-serif !important;
			letter-spacing: .4px !important;
			cursor: pointer !important;
			font-weight: 400 !important;
			text-transform: none !important;
			color: #fff !important;
			border-radius: 2px !important;
			background-color: #5cbe4a !important;
			background-repeat: no-repeat !important;
			line-height: 1.2 !important;
			text-decoration: none !important;
			text-align: left !important;
			text-shadow: none !important;
		}

		.w3_whatsapp_btn_small {
			font-size: 12px;
			background-size: 16px;
			background-position: 5px 2px;
			padding: 3px 6px 3px 25px;
		}

		.w3_whatsapp_btn_medium {
			font-size: 16px;
			background-size: 20px;
			background-position: 4px 2px;
			padding: 4px 6px 4px 30px;
		}

		.w3_whatsapp_btn_large {
			font-size: 16px;
			background-size: 20px;
			background-position: 5px 5px;
			padding: 8px 6px 8px 30px;
			color: #fff;
		}
		a.whatsapp { color: #fff;}
	</style>
</head>
<body>
    <script>
		$(document).ready(function(){
			//$(document).on( "pagecreate", "#pagina-mapa", function() {
				$(document).on({
					ajaxSend: function () { loading('show'); },
					ajaxStart: function () { loading('show'); },
					ajaxStop: function () { loading('hide'); },
					ajaxError: function () { loading('hide'); }
				});

				function loading(showOrHide) {
					setTimeout(function(){
						$.mobile.loading( showOrHide, {
							text: 'La página se encuentra cargando, espere porfavor.',
							textVisible: true,
							theme: 'z',
							html: ""
						});
					}, 1); 
				}
				 <?php
					include_once("modelo/Conexion.class.php");
					$conectar = new Conexion();
				    echo 'var servicios_checkboxes = [';
					$datos = $conectar->listar("SELECT * FROM `servicio`");
					for($x=0;$x<count($datos);$x++){
						echo '{ id : '.$datos[$x]["ID_SERVICIO"].', nombre : "'.$datos[$x]["NOMBRE_SERVICIO"].'", icono : "'.$datos[$x]["ICONO_SERVICIO"].'" }';
						if($x<(count($datos)-1)){
							echo ',';
						}
					}
				    echo '];';
					?>
				 
				 var checkbox = "";
				 for(var x=0; x<servicios_checkboxes.length;x++){
					 checkbox = '<label><input type="checkbox" name="'+servicios_checkboxes[x].id+'" id="'+servicios_checkboxes[x].id+'" /><img src="fotos/iconos/'+servicios_checkboxes[x].icono+'"/> '+servicios_checkboxes[x].nombre+'</label>';
					 $('#grupo-checkbox-filtros').append(checkbox);
					 $('[type=checkbox]').checkboxradio().trigger('create');
					 $('#grupo-checkbox-filtros').controlgroup().trigger('create');
				 }
			//});
		});
	</script>
	<div data-role="page" id="pagina-mapa" data-url="map-page">
  	  <div data-role="panel" id="panel-menu1" data-position="right" class="ui-panel ui-panel-position-right ui-panel-display-reveal ui-body-inherit ui-panel-animate ui-panel-open">
		<div class="ui-panel-inner">
			<ul data-role="listview" class="ui-listview">
				<li data-icon="delete" class="ui-first-child">
					<a href="#" data-rel="close" class="ui-btn ui-btn-icon-right ui-icon-delete">Cerrar</a>
				</li>
				<li>
					<a href="#paginaParametros" class="ui-btn ui-btn-active ui-btn-icon-right ui-icon-carat-r">Mapa</a>
				</li>
				<li>
					<a href="busquedas.php" rel="external" class="ui-btn ui-btn-icon-right ui-icon-carat-r">Búsquedas</a>
				</li>
				<li>
					<a href="#paginaParametros" class="ui-btn ui-btn-icon-right ui-icon-carat-r">¿Quiénes somos?</a>
				</li>
				<li>
					<a href="#paginaMeses" class="ui-btn ui-btn-icon-right ui-icon-carat-r">Contacto</a>
				</li>
				<li class="ui-last-child">
					<a href="login.php" rel="external" class="ui-btn ui-btn-icon-right ui-icon-carat-r">Login</a>
				</li>
			</ul>
		</div>
	</div>
 	  
 	  
 	  <div data-role="panel" id="panel-filtro" data-position="left" class="ui-panel ui-panel-position-left ui-panel-display-reveal ui-body-inherit ui-panel-animate ui-panel-open">
		<div class="ui-panel-inner">
			<ul data-role="listview" class="ui-listview">
				<li data-icon="delete" class="ui-first-child">
					<a href="#" data-rel="close" class="ui-btn ui-btn-icon-right ui-icon-delete">Filtrar</a>
				</li>
				<fieldset data-role="controlgroup" id="grupo-checkbox-filtros">
				</fieldset>
			</ul>
		</div>
	</div>
 	  
 	  
 	  <div data-role="panel" id="mostrar-info-punto" data-position="left" class="ui-panel ui-panel-position-left ui-panel-display-reveal ui-body-inherit ui-panel-animate ui-panel-open">
		<div class="ui-panel-inner" style="height: 100%; overflow: scroll;">
			<h2 class="titulo-local">Pensión Europa</h2>
			<br>
			<div>
				Disponemos de comodas avitaciones y un buffet que se puede ajustar a su preferencia.
			</div>
			
           <br>
           <!-- Start WOWSlider.com BODY section -->
			<div id="wowslider-container1">
			<div class="ws_images"><ul>
					<li><a href="#"><img src="Plugins/data1/images/Pension-Soto.jpg" alt="jquery slideshow" title="Portada" id="wows1_0"/></a></li>
					<li><img src="Plugins/data1/images/Pension-Soto-2.jpg" alt="Sin título" title="Kajak" id="wows1_1"/></li>
				</ul></div>
				<div class="ws_bullets"><div>
					<a href="#" title="Foto2"><span><img src="Plugins/data1/tooltips/foto2.png" alt="Foto2"/>1</span></a>
					<a href="#" title="Sin título"><span><img src="Plugins/data1/tooltips/sin_ttulo.png" alt="Sin título"/>2</span></a>
				</div></div><div class="ws_script" style="position:absolute;left:-99%"><a href="http://wowslider.net">image slider</a> by WOWSlider.com v8.8</div>
			<div class="ws_shadow"></div>
			</div>	
			<script type="text/javascript" src="Plugins/engine1/wowslider.js"></script>
			<script type="text/javascript" src="Plugins/engine1/script.js"></script>
			<!-- End WOWSlider.com BODY section -->
            <br>
        <div data-role="controlgroup" data-type="horizontal">
          <a href="tel:+56968399881" class="ui-btn ui-corner-all">
		  	<i class="icofont icofont-ui-call"></i>
		  </a>
		  <a href="https://api.whatsapp.com/send?phone=56968399881" class="w3_whatsapp_btn ui-btn ui-corner-all">
		  	<i class="icofont icofont-brand-whatsapp"></i>
		  </a>
		  <a href="https://m.me/roy.a.barraza" class="w3_face_messenger_btn ui-btn ui-corner-all">
		  	<i class="icofont icofont-social-facebook-messenger"></i>
		  </a>
		  <a href="https://www.facebook.com/roy.a.barraza" class="w3_facebook_btn ui-btn ui-corner-all">
		  	<i class="icofont icofont-social-facebook"></i>
		  </a>
		  <a href="https://www.neosystemspa.cl" class="ui-btn ui-corner-all">
		  	<i class="icofont icofont-web"></i>
		  </a>
		  <a href="#" data-rel="close" class="ui-btn ui-corner-all">
		  	<i class="icofont icofont-info-circle"></i>
		  </a>
		  <a href="#" data-rel="close" class="ui-btn ui-corner-all">
		  	<i class="icofont icofont-close-squared"></i>
		  </a>
		</div>
		</div>
	</div>
  	  
	  <div data-role="header" data-position="fixed" data-theme="a">
		<h1>Guía del Turista</h1>
		<a href="#panel-menu1"  data-icon="grid" class="ui-btn-right">Menú</a>
		<a href="#panel-filtro" data-icon="search" class="ui-btn-left">Filtro</a>
	  </div>
	  <div data-role="main" class="ui-content" id="map">
	  </div>
	  <div data-role="footer" style="text-align:center;" data-position="fixed">
		<div data-role="controlgroup" data-type="horizontal">
	  	  <a href="#" onClick="ver_donde_estoy();" class="ui-btn ui-corner-all ui-shadow ui-icon-location ui-btn-icon-left">Donde estoy?</a>
		  
		</div>
	  </div>
	  
	</div> 
	
	
	<script>
		var datos_del_punto_clickeado = new Array();
		$(document).ready(function(){
			$("#mostrar-info-punto").on("panelopen", function( event, ui ) {
				
			});
		});
		class Ajax{
			constructor(){

			}
			enviar(parametros,url){
				var enviados = null;
				try{
					enviados = $.ajax({
									url: url,
									type:'POST',
									data:parametros,
									beforeSend: function(){/* mientras este sucediendo el evento sucederá lo siguiente*/
										$.mobile.loader.prototype.options.text = "Cargando";
										$.mobile.loader.prototype.options.textVisible = false;
										$.mobile.loader.prototype.options.theme = "a";
										$.mobile.loader.prototype.options.html = "";
									},
									error: function(XMLHttlRequest, textStatus, errorThrown){
										alert(errorThrown);
									} /* Si sucede un error se llamará a la función callback_error*/
								});
				}catch(ex){
					alert(ex);
				}
				return enviados;
			}
		}
		var objetoAjax = new Ajax();
		
		
		var mapa = null;
		function initMap(position) {
			var latitud;
			var longitud;
		  	var myLatLng;
			if(position!=null){
				latitud = position.coords.latitude;
				longitud = position.coords.longitude;
			}else{
				latitud = -29.902669099999997;
				longitud = -71.2519374;
			}
		  myLatLng = {lat: latitud, lng: longitud};

		  mapa = new google.maps.Map(document.getElementById('map'), {
			zoom: 16,
			center: myLatLng
		  });

		  marcar_empresas();
		  if(position!=null){
			geolocalizar_usuario();
		  }
		}
		var sitios_localizados = new Array();
		function marcar_empresas(){
			var parametros = {
				'accion' : 'mostrarMapa'	
			};
			var respuesta_ajax = objetoAjax.enviar(parametros,'controlador/mapas.php');
			respuesta_ajax.done(function( datos ) {
				datos = JSON.parse(datos);
				for(var x=0;x<datos.length;x++){
					var marcador = new google.maps.Marker({
						position: {lat: parseFloat(datos[x].LATITUD_NEGOCIO), lng: parseFloat(datos[x].LONGITUD_NEGOCIO)},
						map: mapa,
						icon: 'fotos/iconos/'+datos[x].ICONO_SERVICIO,
						title: datos[x].NOMBRE_SERVICIO
					});
					var html = '<div class="ui-panel-inner" style="height: 100%; overflow: scroll;">'
						+'<h2 class="titulo-local">'+datos[x].NOMBRE_DE_FANTASIA_NEGOCIO+'</h2>'
						+'<br>'
						+'<div>'
							+datos[x].DESCRIPCION_NEGOCIO
						+'</div>'

					   +'<br>';
					
					html    +='<!-- Start WOWSlider.com BODY section -->'
								+'<div id="wowslider-container1">'
								+'<div class="ws_images"><ul>';
					var fotos = "";
					for(var i=0;i<datos[x].FOTOS.length;i++){
						
						html    += '<li><a href="#"><img src="fotos/fotos-destinos/'+datos[x].FOTOS[i].UBICACION_FOTO+'" alt="jquery slideshow" title="'+datos[x].FOTOS[i].NOMBRE_FOTO+'" id="wows1_0"/></a></li>';
					}
					html    +='</ul></div>'
									+'<div class="ws_bullets"><div>'
										+'<a href="#" title="Foto2"><span><img src="Plugins/data1/tooltips/foto2.png" alt="Foto2"/>1</span></a>'
										+'<a href="#" title="Sin título"><span><img src="Plugins/data1/tooltips/sin_ttulo.png" alt="Sin título"/>2</span></a>'
									+'</div></div><div class="ws_script" style="position:absolute;left:-99%"><a href="http://wowslider.net">image slider</a> by WOWSlider.com v8.8</div>'
								+'<div class="ws_shadow"></div>'
								+'</div>'
								+'<script type="text/javascript" src="Plugins/engine1/wowslider.js"><'+'/script>'

								+'<script type="text/javascript" src="Plugins/engine1/script.js"><'+'/script>'
					html    +='<br>'
							+'<div data-role="controlgroup" data-type="horizontal">'
							  +'<a href="tel:+'+datos[x].CELULAR_NEGOCIO+'" class="ui-btn ui-corner-all">'
								+'<i class="icofont icofont-ui-call"></i>'
							  +'</a>'
							  +'<a href="https://api.whatsapp.com/send?phone='+datos[x].CELULAR_NEGOCIO+'" class="w3_whatsapp_btn ui-btn ui-corner-all">'
								+'<i class="icofont icofont-brand-whatsapp"></i>'
							  +'</a>'
							  +'<a href="https://m.me/'+datos[x].NOMBRE_USUARIO_FACEBOOK_NEGOCIO+'" class="w3_face_messenger_btn ui-btn ui-corner-all">'
								+'<i class="icofont icofont-social-facebook-messenger"></i>'
							  +'</a>'
							  +'<a href="'+datos[x].FACEBOOK_NEGOCIO+'" class="w3_facebook_btn ui-btn ui-corner-all">'
								+'<i class="icofont icofont-social-facebook"></i>'
							  +'</a>'
							  +'<a href="'+datos[x].PAGINA_WEB_NEGOCIO+'" class="ui-btn ui-corner-all">'
								+'<i class="icofont icofont-web"></i>'
							  +'</a>'
							  +'<a href="#" data-rel="close" class="ui-btn ui-corner-all">'
								+'<i class="icofont icofont-info-circle"></i>'
							  +'</a>'
							  +'<a href="#" data-rel="close" class="ui-btn ui-corner-all">'
								+'<i class="icofont icofont-close-squared"></i>'
							  +'</a>'
							+'</div>'
							+'</div>';
					marcador.addListener('click', function() {
						datos_del_punto_clickeado = new Array();
						datos_del_punto_clickeado.push({
							
						});
						$("#mostrar-info-punto").html(html);
						$("#mostrar-info-punto").trigger('updatelayout');
						$("#mostrar-info-punto").trigger('create');
						$("#mostrar-info-punto").panel("open");
						
						//$( "#mostrar-info-punto" ).panel( "open" );
					});

					var infowindow = new google.maps.InfoWindow();
					var contenido = 'Disponemos de comodas avitaciones y un buffet que se puede ajustar a su preferencia.';
				}
			});
		}

		function limpiar(){
			navigator.geolocation.getCurrentPosition(initMap,
													 onErrorGeolocating,
			                                         {
			                                         		enableHighAccuracy: true,
															maximumAge: 30000,
															timeout: 27000
			                                         });
		}
		function onErrorGeolocating(error){
			switch(error.code){
				case error.PERMISSION_DENIED:
					alert('ERROR: User denied access to track physical position!');
				break;
				
				case error.POSITION_UNAVAILABLE:
					alert("ERROR: There is a problem getting the position of the device!");
				break;
				
				case error.TIMEOUT:
					alert("ERROR: The application timed out trying to get the position of the device!");
				break;
				
				default:
					alert("ERROR: Unknown problem!");
				break;
			}
		}
		function iniciar_mapa(){
			initMap(null);
		}

		function geolocalizar_usuario(){
			obtener_coordenadas_usuario();
			setInterval(function(){ obtener_coordenadas_usuario(); }, 10000);
		}

		function obtener_coordenadas_usuario(){
			if(navigator.geolocation){
				navigator.geolocation.getCurrentPosition(function(position) {
						/*var marcador = null;
						//var imagen = '../../core/images/factory_google_maps-con-fondo.png';

						var marcador = new google.maps.Marker({
							position: {lat:position.coords.latitude, lng:position.coords.longitude},
							map: mapa,
							title: 'tu'
						});
						marcador.setMap(mapa);*/

						  addMarker({lat:position.coords.latitude, lng:position.coords.longitude});
						$("#prueba").html("Latitud : "+position.coords.latitude+' Longitud : '+position.coords.longitude);
					}, onErrorGeolocating
					, {
						enableHighAccuracy: true,
						maximumAge: 30000,
						timeout: 27000
					}
				);
			}else{
					// El navegador no soporta la geolicalización

			}
		}
		var posicion_antigua_usuario = new Array();
		var latitud_longitud_usuario = new Array();
		var es_primera_vez = true;
		function addMarker(location) {
			//console.log(posicion_antigua_usuario.length+'>'+0+' = '+posicion_antigua_usuario.length>0);
			//console.log(posicion_antigua_usuario);
		  if(es_primera_vez==false){
			posicion_antigua_usuario.setMap(null);
			posicion_antigua_usuario.length = 0;
			$("#prueba").html("Eliminado "+posicion_antigua_usuario);
			//console.log("Eliminando");
		  }else{
			es_primera_vez = false;
		  } 
		  //console.log(posicion_antigua_usuario);
		  var foto = 'fotos/breastfeeding.png';
		  var marker = new google.maps.Marker({
			position: location,
			map: mapa,
			icon: foto
		  });
		  posicion_antigua_usuario = marker; 
		  latitud_longitud_usuario = location;
		}
		var marcador_posicion_antigua_usuario = null;
		function localizar_usuario(latitud_longitud_usuario){
			if(marcador_posicion_antigua_usuario==null){
				
			}else{
				marcador_posicion_antigua_usuario.setMap(null);
			}
			var latitud = latitud_longitud_usuario.lat;
			var longitud = latitud_longitud_usuario.lng;
			var foto = 'fotos/breastfeeding.png';
			var marker = new google.maps.Marker({
				position: latitud_longitud_usuario,
				map: mapa,
				icon: foto
			});
			marcador_posicion_antigua_usuario = marker;
			mapa.setCenter({lat: latitud, lng: longitud});//mostrar posicion actual usuario
		}
		function ver_donde_estoy(){
			navigator.geolocation.getCurrentPosition(function(position){
				var latitud = position.coords.latitude;
				var longitud = position.coords.longitude;
				latitud_longitud_usuario = {lat: latitud, lng: longitud};
				localizar_usuario(latitud_longitud_usuario);
			},
			 onErrorGeolocating,
			 {
					enableHighAccuracy: true,
					maximumAge: 30000,
					timeout: 27000
			 });
		}
		function mover_camara(){
			mapa.setCenter({lat : -29.956547333764615, lng: -71.33786827325821});
		}
		$(document).ready(function() {
			
		
		});
	</script>
	
	<script async defer
        src="https://maps.googleapis.com/maps/api/js?key=AIzaSyCGx6vx7-gnREjJZ2--XIn_tFw9SUuG6BA&callback=iniciar_mapa"></script>
</body>
</html>