<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=0">
	<title>Guía del Turista</title>
	<link rel="stylesheet" href="Plugins/themes/fumysam.min.css" />
	<link rel="stylesheet" href="Plugins/themes/jquery.mobile.icons.min.css" />
	<link rel="stylesheet" href="https://code.jquery.com/mobile/1.4.5/jquery.mobile.structure-1.4.5.min.css" />
	<script src="https://code.jquery.com/jquery-1.11.1.min.js"></script>
	<script src="https://code.jquery.com/mobile/1.4.5/jquery.mobile-1.4.5.min.js"></script>
	<!-- Start WOWSlider.com HEAD section -->
	<link rel="stylesheet" type="text/css" href="Plugins/engine1/style.css" />
	
	<!-- End WOWSlider.com HEAD section -->
    
	<style>
		#pagina-mapa { width: 100%; height: 70%; padding: 0; }
		#map { width: 98%; height: 95%; }
		.titulo-local {
			color: #3eb249;
			background-color: transparent;
			border-bottom: 1px solid #ddd;
			font-size: 1.6em;
			padding-bottom: .2em;
			margin: 0 0 .7375em;
		}
	</style>
</head>
<body>
	<div data-role="page" id="pagina-mapa" data-url="map-page">
  	  
  	  <div data-role="panel" id="panel-menu1" data-position="right" class="ui-panel ui-panel-position-right ui-panel-display-reveal ui-body-inherit ui-panel-animate ui-panel-open">
		<div class="ui-panel-inner">
			<ul data-role="listview" class="ui-listview">
				<li data-icon="delete" class="ui-first-child">
					<a href="#" data-rel="close" class="ui-btn ui-btn-icon-right ui-icon-delete">Cerrar</a>
				</li>
				<li>
					<a href="index.php" rel="external" class="ui-btn ui-btn-icon-right ui-icon-carat-r">Mapa</a>
				</li>
				<li>
					<a href="#" class="ui-btn ui-btn-active ui-btn-icon-right ui-icon-carat-r">Búsquedas</a>
				</li>
				<li>
					<a href="#paginaParametros" class="ui-btn ui-btn-icon-right ui-icon-carat-r">¿Quiénes somos?</a>
				</li>
				<li>
					<a href="#paginaMeses" class="ui-btn ui-btn-icon-right ui-icon-carat-r">Contacto</a>
				</li>
				<li class="ui-last-child">
					<a href="login.php" rel="external" class="ui-btn ui-btn-icon-right ui-icon-carat-r">Login</a>
				</li>
			</ul>
		</div>
	</div>
 	  
 	  
 	  <div data-role="panel" id="panel-filtro" data-position="left" class="ui-panel ui-panel-position-left ui-panel-display-reveal ui-body-inherit ui-panel-animate ui-panel-open">
		<div class="ui-panel-inner">
			<ul data-role="listview" class="ui-listview">
				<li data-icon="delete" class="ui-first-child">
					<a href="#" data-rel="close" class="ui-btn ui-btn-icon-right ui-icon-delete">Filtrar</a>
				</li>
				<fieldset data-role="controlgroup">
					<input type="checkbox" name="checkbox-v-2a" id="checkbox-v-2a">
					<label for="checkbox-v-2a">Camping</label>
					<input type="checkbox" name="checkbox-v-2b" id="checkbox-v-2b">
					<label for="checkbox-v-2b">Kajak</label>
					<input type="checkbox" name="checkbox-v-2c" id="checkbox-v-2c">
					<label for="checkbox-v-2c">Hostal</label>
					<input type="checkbox" name="checkbox-v-2d" id="checkbox-v-2d">
					<label for="checkbox-v-2d">Aventura</label>
				</fieldset>
			</ul>
		</div>
	</div>
	  <div data-role="header" data-position="fixed" data-theme="a">
		<h1>Guía del Turista</h1>
		<a href="#panel-menu1"  data-icon="grid" class="ui-btn-right">Menú</a>
		<a href="#panel-filtro" data-icon="bullets" class="ui-btn-left">Filtro</a>
		<table style="min-width: 95%; max-width: 95%;">
			<tr>
				<td style="width: 80%;">
				<input type="search" name="search-2" id="search-2" value="" data-mini="true" placeholder="Search / Buscar" />
				</td>
				<td style="width: 20%;">
					<button class="ui-shadow ui-btn ui-corner-all ui-icon-search ui-btn-icon-right">Search</button>
				</td>
			</tr>
		</table>		
	  </div>
	  <div data-role="main" class="ui-content" id="map">
	  	<ul data-role="listview" data-inset="true">
			<li>
				<a href="#">
				<img src="fotos/fotos-destinos/Huilo-huilo.jpg">
				<h2>Huilo-Huilo</h2>
				<p>Enclavada en el corazón de la Selva Patagónica de Chile y rodeada por la majestuosa Cordillera de los Andes, nace la Reserva Biológica Huilo Huilo, un proyecto único en el mundo por su compromiso con la conservación del patrimonio natural y cultura local. Le invitamos a un viaje fascinante por las maravillas de nuestra mágica Reserva y a conocer nuestro compromiso en las áreas de Turismo Sustentable, Fundación y Territorio.</p>
				<p><strong>Chiloé, Región de Los Lagos</strong></p>
				</a>
			</li>
			<li><a href="#">
				<img src="fotos/fotos-destinos/turavion.jpg" style="height: 100%;">
				<h2>Turavion</h2>
				<p>Ofrecemos tures en avion y alojamiento.</p>
				<p><strong>Chiloé, Región de Los Lagos</strong></p>
			</a>
			</li>
			<li><a href="#">
				<img src="fotos/fotos-destinos/ruta-termas-del-sur-de-chile.jpg">
				<h2>Manantial / Termas Sur de Chile</h2>
				<p>Ofrecemos alojamiento y baños en termas curativas para enfermedades osteo-musculares.</p>
				<p><strong>Chiloé, Región de Los Lagos</strong></p>
				</a>
			</li>
		</ul>
	  </div>
	</div> 
</body>
</html>